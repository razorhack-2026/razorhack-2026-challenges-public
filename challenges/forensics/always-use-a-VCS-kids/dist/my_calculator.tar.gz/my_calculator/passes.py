from lexer import Lexer
from parser import Parser, ASTNode, ParseError
from walker import _walk_node

def parse(src: str) -> tuple[ASTNode, list[ParseError]]:
    lexer = Lexer(src)
    parser = Parser(lexer)
    ast = parser.pratt(0)
    return (ast, parser.errs)

def walk_ast(ast: ASTNode) -> int | float:
    return _walk_node(ast)
