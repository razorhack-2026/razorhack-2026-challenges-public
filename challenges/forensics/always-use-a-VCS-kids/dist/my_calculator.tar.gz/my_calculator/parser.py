from span import Span
from lexer import Lexer, Token, TokenKind

from abc import ABC
from dataclasses import dataclass
import enum

@dataclass
class ASTNode(ABC):
    span: Span


class InfixOp(enum.StrEnum):
    ADD = '+'
    SUB = '-'
    MUL = '*'
    DIV = '/'

def infix_bp(op: InfixOp) -> tuple[int, int]:
    match op:
        case InfixOp.ADD | InfixOp.SUB: return (1, 2)
        case InfixOp.MUL | InfixOp.DIV: return (3, 4)

@dataclass
class InfixExpr(ASTNode):
    lhs: ASTNode
    rhs: ASTNode
    op: InfixOp


class PrefixOp(enum.StrEnum):
    POS  = '+'
    NEG  = '-'

def prefix_bp(op: PrefixOp) -> tuple[int, int]:
    match op:
        case InfixOp.POS | InfixOp.NEG: return (0, 5)

@dataclass
class PrefixExpr(ASTNode):
    rhs: ASTNode
    op: PrefixOp


@dataclass
class NumExpr(ASTNode):
    val: str


@dataclass
class ErrorExpr(ASTNode):
    pass

@dataclass
class ParseError:
    msg: str
    ast_node: ErrorExpr


class Parser:
    def __init__(self, lex: Lexer):
        self.lex = lex
        self.buf = self.lex.next_token()
        self.errs: list[ParseError] = []

    def _peek_token(self) -> Token:
        return self.buf

    def _bump_token(self) -> Token:
        t = self.buf
        self.buf = self.lex.next_token()
        return t

    def _parse_prefix(self, span: Span, op: PrefixOp) -> PrefixExpr:
        (_, r_bp) = prefix_bp(op)
        rhs = self.pratt(r_bp)

        span = Span(
            idx=span.idx,
            length=span.length+rhs.span.length,
            line=span.line,
            column=span.column,
        )

        return PrefixExpr(
            span=span,
            rhs=rhs,
            op=op,
        )

    def _push_err(self, span: Span, msg: str) -> ErrorExpr:
        err = ErrorExpr(span=span)
        self.errs.append(ParseError(msg=msg, ast_node=err))
        return err

    def pratt(self, min_bp: int) -> ASTNode:
        tok = self._bump_token()
        match tok.kind:
            case TokenKind.PLUS:
                lhs = self._parse_prefix(tok.span, PrefixOp.POS)
            case TokenKind.MINUS:
                lhs = self._parse_prefix(tok.span, PrefixOp.NEG)

            case TokenKind.LPAREN:
                lhs = self.pratt(0)

                # TODO: There's probably a better way to do this
                if (tok := self._bump_token().kind != TokenKind.RPAREN):
                    return self._push_err(
                        span=lhs.span,
                        msg=f'Expected a `)` but found `{str(tok)}`'
                    )

            case TokenKind.NUMBER:
                lhs = NumExpr(
                    tok.span,
                    self.lex.get_src(tok.span)
                )

            # TODO: Better Error Recovery?
            case _:
                return self._push_err(
                    span=tok.span,
                    msg=f'Expected a number, a prefix operator, or `(` but found `{self.lex.get_src(tok.span)}`'
                )

        while True:
            tok = self._peek_token()
            match tok.kind:
                case TokenKind.EOF | TokenKind.RPAREN:
                    break

                case TokenKind.PLUS:   op = InfixOp.ADD
                case TokenKind.MINUS:  op = InfixOp.SUB
                case TokenKind.STAR:   op = InfixOp.MUL
                case TokenKind.FSLASH: op = InfixOp.DIV

                case _:
                    return self._push_err(
                        span=tok.span,
                        msg=f'Expected an infix operator but found `{self.lex.get_src(tok.span)}`'
                    )

            (l_bp, r_bp) = infix_bp(op)
            if l_bp < min_bp:
                break

            self._bump_token()

            rhs = self.pratt(r_bp)

            span = Span(
                idx=lhs.span.idx,
                length=lhs.span.length+rhs.span.length,
                line=lhs.span.line,
                column=lhs.span.column,
            )

            lhs = InfixExpr(
                span=span,
                lhs=lhs,
                rhs=rhs,
                op=op,
            )

        return lhs

