from dataclasses import dataclass

@dataclass
class Span:
    idx: int
    length: int
    line: int
    column: int

