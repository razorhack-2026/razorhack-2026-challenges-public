from span import Span
from dataclasses import dataclass
import enum

class TokenKind(enum.StrEnum):
    PLUS   = '+'
    MINUS  = '-'
    STAR   = '*'
    FSLASH = '/'

    LPAREN = '('
    RPAREN = ')'

    NUMBER = enum.auto()
    ERROR  = enum.auto()
    EOF    = enum.auto()


@dataclass
class Token:
    kind: TokenKind
    span: Span

class Lexer:
    def __init__(self, src: str):
        self.src = src
        self.idx = 0
        self.line = 1
        self.column = 1


    def _peek_char(self) -> str:
        return self.src[self.idx] if self.idx < len(self.src) else None


    def _bump_char(self):
        if self.idx >= len(self.src):
            return

        if self._peek_char() == '\n':
            self.line += 1
            self.column = 0

        self.idx += 1
        self.column += 1


    def _lex_num(self) -> Token:
        start_idx = self.idx
        start_column = self.column
        length = 0

        c = self._peek_char()
        while c is not None and c.isdecimal():
            self._bump_char()
            length += 1
            c = self._peek_char()

        return Token(
            kind=TokenKind.NUMBER,
            span=Span(
                idx=start_idx,
                length=length,
                line=self.line,
                column=start_column,
            ),
        )


    def _lex_symbol(self, kind: TokenKind) -> Token:
        tok = Token(
            kind=kind,
            span=Span(
                idx=self.idx,
                length=1,
                line=self.line,
                column=self.column,
            ),
        )

        self.idx += 1
        self.column += 1

        return tok


    def _lex_error(self) -> Token:
        start_idx = self.idx
        start_column = self.column
        length = 0

        c = self._peek_char()
        while c is not None and not c.isspace():
            self._bump_char()
            length += 1
            c = self._peek_char()

        return Token(
            kind=TokenKind.ERROR,
            span=Span(
                idx=start_idx,
                length=length,
                line=self.line,
                column=start_column,
            ),
        )


    def next_token(self) -> Token | None:
        c = self._peek_char()
        while c is not None and c.isspace():
            self._bump_char()
            c = self._peek_char()

        if c is None:
            return Token(
                kind=TokenKind.EOF,
                span=Span(
                    idx=self.idx,
                    length=0,
                    line=self.line,
                    column=self.column,
                )
            )

        if c.isdecimal():
            return self._lex_num()

        match c:
            case TokenKind.PLUS:   return self._lex_symbol(TokenKind.PLUS)
            case TokenKind.MINUS:  return self._lex_symbol(TokenKind.MINUS)
            case TokenKind.STAR:   return self._lex_symbol(TokenKind.STAR)
            case TokenKind.FSLASH: return self._lex_symbol(TokenKind.FSLASH)
            case TokenKind.LPAREN: return self._lex_symbol(TokenKind.LPAREN)
            case TokenKind.RPAREN: return self._lex_symbol(TokenKind.RPAREN)

            case v if v.isdecimal(): return self._lex_num()
            case _: return self._lex_error()

    def get_src(self, span: Span) -> str:
        return self.src[span.idx:span.idx+span.length]

