from parser import ASTNode, InfixExpr, InfixOp, PrefixExpr, PrefixOp, NumExpr

def _infix_expr(lhs: int, rhs: int, op: InfixOp) -> int | float:
    match op:
        case InfixOp.ADD: return lhs + rhs
        case InfixOp.SUB: return lhs - rhs
        case InfixOp.MUL: return lhs * rhs
        case InfixOp.DIV: return lhs / rhs

def _prefix_expr(rhs: int, op: PrefixOp) -> int | float:
    match op:
        case PrefixOp.NEG: return -rhs
        case PrefixOp.POS: return +rhs

def _walk_node(node: ASTNode) -> int | float | None:
    match node:
        case InfixExpr(_, lhs, rhs, op):
            lhs_ = _walk_node(lhs)
            if lhs_ is None: return None

            rhs_ = _walk_node(rhs)
            if rhs_ is None: return None

            return _infix_expr(lhs_, rhs_, op)

        case PrefixExpr(_, rhs, op):
            rhs_ = _walk_node(rhs)
            if rhs_ is None: return None

            return _prefix_expr(rhs_, op)

        case NumExpr(_, val):
            return int(val)

        case _:
            return None
