#!/usr/bin/env python3
from passes import parse, walk_ast
import sys

instrs = '''\
Supported operations:
- '+': Addition
- '-': Subtraction
- '*': Multiplication
- '/': Division

'exit' to exit the REPL
'''
if __name__ == '__main__':
    print(instrs)
    while True:
        src = input("> ")
        if src == 'exit':
            break

        (ast, errs) = parse(src)

        if len(errs) == 0:
            print(f'{walk_ast(ast)}\n', file=sys.stdout)
        
        for err in errs:
            print(err, file=sys.stderr)
